const fs = require('fs')
const path = require('path')
const webpack = require('webpack')
const config = require('../config')
// const pkg = require('../app/package.json')

const nodeModules = (() => {
  const nodeModules = {}
  try {
    fs.readdirSync(path.resolve(__dirname, '../app/node_modules'))
      .filter(x => x !== '.bin')
      .forEach(mod => { nodeModules[mod] = 'commonjs ' + mod })
    return nodeModules
  } catch (e) {
    return {}
  }
})()

module.exports = {
  context: __dirname,
  output: {
    path: config.bundle.root,
    filename: '[name].js',
    libraryTarget: 'commonjs2'
  },
  module: {
    loaders: [
      { test: /\.js$/, loader: 'babel', exclude: /node_modules/, query: { presets: ['es2015-loose'] } },
      { test: /\.json$/, loader: 'json' },
      { test: /\.vue$/, loader: 'vue' },
      { test: /\.css$/, loader: ExtractTextPlugin.extract('style', 'css') },
      { test: /\.less$/, loader: ExtractTextPlugin.extract('style', 'css!less') },
      { test: /\.(png|jpe?g|gif|svg)(\?.*)?$/, loader: 'url', query: { limit: 10000, name: 'img/[name].[hash:7].[ext]' } },
      { test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/, loader: 'url', query: { limit: 10000, name: 'font/[name].[hash:7].[ext]' } }
    ]
  },
  resolve: {
    extensions: ['', '.js', '.json', '.css', '.less', '.sass', '.scss', '.vue'],
    fallback: [path.resolve(__dirname, '../node_modules')],
    alias: { app: path.resolve(__dirname, '../app') }
  },
  resolveLoader: {
    fallback: [path.resolve(__dirname, '../node_modules')]
  },
  // externals: nodeModules, // Object.keys(pkg.dependencies || {}),
  node: {
    __filename: false,
    __dirname: false
  },
  plugins: [
    new webpack.ExternalsPlugin('commonjs2', nodeModules)
  ],
  vue: {
    loaders: {
      css: ExtractTextPlugin.extract("css"),
      less: ExtractTextPlugin.extract("css!less")
    }
  }
}

const merge = require('webpack-merge')
const base = require('./webpack.config.base')

const config = module.exports = merge(base, {
  entry: {
    main: '../app/main.js',
    renderer: '../app/renderer.js',
  },
  target: 'electron-renderer',
  plugins: [
    new CopyWebpackPlugin([
      { from: '../app/package.json', to: '../build' },
      { from: '../app/node_modules', to: '../build/node_modules' }
    ]),
    // http://vuejs.github.io/vue-loader/workflow/production.html
    new webpack.DefinePlugin({
      'process.env': { NODE_ENV: JSON.stringify('production') }
    }),
    new webpack.optimize.UglifyJsPlugin({ compress: { warnings: false } }),
    new webpack.optimize.OccurenceOrderPlugin(),
    // extract css into its own file
    new ExtractTextPlugin(path.join(config.build.assetsSubDirectory, '[name].css')),
    // generate dist index.html with correct asset hash for caching.
    // you can customize output by editing /index.html
    // see https://github.com/ampedandwired/html-webpack-plugin
    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: './app/index.html',
      excludeChunks: ['main'],
      inject: true,
      minify: {
        removeComments: true,
        collapseWhitespace: true,
        removeAttributeQuotes: true
        // more options:
        // https://github.com/kangax/html-minifier#options-quick-reference
      }
    })
  ],
  stats: {
    colors: true
  }
})

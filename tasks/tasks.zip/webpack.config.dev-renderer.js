const webpack = require('webpack')
const merge = require('webpack-merge')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const base = require('./webpack.config.base')

const config = module.exports = merge(base, {
  entry: {
    renderer: ['../app/renderer.js']
  },
  // module: {
  //   loaders: [
  //     { test: /\.js$/, loader: 'babel', exclude: /node_modules/, query: { presets: ['es2015-loose'] } },
  //   ]
  // },
  target: 'electron-renderer',
  plugins: [
    // Copy files from app to dist
    new CopyWebpackPlugin([
      { from: '../app/node_modules', to: '../build/node_modules' }
    ]),
    new webpack.DefinePlugin({
      'process.env': {
        NODE_ENV: '"development"'
      }
    }),
    // https://github.com/glenjamin/webpack-hot-middleware#installation--usage
    new webpack.optimize.OccurenceOrderPlugin(),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoErrorsPlugin(),
    // https://github.com/ampedandwired/html-webpack-plugin
    new HtmlWebpackPlugin({
      filename: 'index.html',
      template: '../app/index.html',
      excludeChunks: ['devtools'],
      inject: true
    })
  ]
})

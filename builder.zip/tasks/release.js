const builder = require('electron-builder')
const appPkg = require('../build/package.json')
const devPkg = require('../package.json')
// https://github.com/xwartz/PupaFM

const Platform = builder.Platform

// Promise is returned
builder.build({
  targets: Platform.WINDOWS.createTarget(),
  metadata: {
    name: appPkg.name,
    productName: appPkg.productName,
    version: appPkg.version,
    description: appPkg.description,
    author: appPkg.author,
    homepage: appPkg.homepage,
    license: appPkg.license
  },
  devMetadata: {
    // "//": "build and other properties, see https://goo.gl/5jVxoO"
    build: {
      'appId': 'net.wedn.builder',
      'app-category-type': 'public.app-category.productivity',
      'asar': true,
      'productName': 'Demo',
      'files': ['**\/*'],
      'iconUrl': `file://${__dirname}/resources/icon.ico`,
      'mac': {
        target: 'dmg',
        identity: ''
      },
      'dmg': {},
      'mas': {},
      'win': {},
      'nsis': {},
      'linux': {},
      'compression': 'normal'
    },
    directories: {
      app: 'build',
      output: 'dist',
      buildResources: 'tasks/resources'
    }
  }
})
.then((res) => {
  // handle result
  console.log(res)
})
.catch((error) => {
  // handle error
  console.log(error)
})
